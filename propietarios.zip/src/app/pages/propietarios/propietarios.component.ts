import { Component, OnInit } from '@angular/core';
import { Propietario } from 'src/app/model/propietario';
import { PropietarioService } from 'src/app/services/propietario.service';

@Component({
  selector: 'app-propietarios',
  templateUrl: './propietarios.component.html',
  styleUrls: ['./propietarios.component.css']
})
export class PropietariosComponent implements OnInit {

  propietarios : Propietario[] = [];

  constructor(private serviceProp : PropietarioService) { }

  ngOnInit(): void {
    this.getPropietarios();
  }

  getPropietarios(){
    this.serviceProp.getPropietarios().subscribe(
      propietarios => this.propietarios = propietarios
    );
  }
}
