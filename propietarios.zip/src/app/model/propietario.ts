export class Propietario {
    public Identificacion? : string;
    public Nombres? : string;
    public Apellidos? : string;
    public TipoIdentificacion? : string;

    constructor(){}
}
