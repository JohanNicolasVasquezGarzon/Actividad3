import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Propietario } from '../model/propietario';

@Injectable({
  providedIn: 'root'
})
export class PropietarioService {
  private url = environment.endpoint;

  constructor(private http : HttpClient) { }

  getPropietarios() : Observable<Propietario[]>{
    return this.http.get<Propietario[]>(this.url+'propietarios');
  }
}
